const o = {
  a: 'a',
  b: 'b',
  obj: {
    key: 'key',
  },
}

const o2 = o

o2.a = 'new value'

// o и o2 указывают на один и тот же объект
console.log(o.a)

// shallow copy - поверхностное копирование o в o3
const o3 = Object.assign({}, o)

// deep copy - глубокое копирование
function deepCopy(obj) {
  // проверка на наличие объектов
  // в случае нахождения, копировать данный объект (deep copy)
  // иначе вернуть значение
  const keys = Object.keys(obj)

  const newObject = {}

  for (let i = 0; i < keys.length; i++) {
    const key = keys[i]
    if (typeof obj[key] === 'object') {
      newObject[key] = deepCopy(obj[key])
    } else {
      newObject[key] = obj[key]
    }
  }

  return newObject
}

const o4 = deepCopy(o)

o.obj.key = 'new key!'
console.log(o4.obj.key)
