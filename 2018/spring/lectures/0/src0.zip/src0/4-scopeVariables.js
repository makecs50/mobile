// у "var" лексическая область видимости, т.е. существует с места объявления и до завершения функции
if (true) {
  var lexicallyScoped = 'This exists until the end of the function'
}

console.log(lexicallyScoped)

// у "let" и "const" блочная область видимости  are block scoped
if (true) {
  let blockScoped = 'This exists until the next }'
  const alsoBlockScoped = 'As does this'
}

// данная переменная не существует
console.log(typeof blockScoped)

thisIsAlsoAVariable = "hello"

const thisIsAConst = 50

// thisIsAConst++ // ошибка!

const constObj = {}

// const все еще можно изменить (так как мы изменяем не значение const, а только то, на что он указывает)
constObj.a = 'a'

let thisIsALet = 51
thisIsALet = 50

// let thisIsALet = 51 // ошибка!

var thisIsAVar = 50
thisIsAVar = 51
var thisIsAVar = 'new value!'
