const x = 42

// получить тип данных, используя "typeof"
console.log(typeof x)
console.log(typeof undefined)

// это может вас удивить...
console.log(typeof null)
