// функции подвергаются hoisting'у (т.е. поднятию)
hoistedFunction()

// но только если они объявляются как функции, а не как
// значения каких-либо переменных
console.log("typeof butNotThis: " + typeof butNotThis)

function thisShouldWork() {
    console.log("functions are hoisted")
}

var butNotThis = function() {
    console.log("but variables aren't")
}
